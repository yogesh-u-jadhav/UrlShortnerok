package com.example.UrlShortnerok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShortnerokApplicationTests {

	@Test
	void contextLoads() {
	}

}
